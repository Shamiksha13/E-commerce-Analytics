// Sample data taken from the report appendix
const monthly = [
  { name: "Dec 2010", value: 748854.84 },
  { name: "Jan 2011", value: 560000.12 },
  { name: "Feb 2011", value: 498245.33 },
  { name: "Mar 2011", value: 683092.11 },
  { name: "Apr 2011", value: 642733.56 },
  { name: "May 2011", value: 723611.45 }
];

const countries = [
  { name: "United Kingdom", value: 8187806.36 },
  { name: "Netherlands", value: 285446.34 },
  { name: "EIRE", value: 263276.82 },
  { name: "Germany", value: 228867.14 },
  { name: "France", value: 209715.11 }
];

function drawChart(id, data) {
  const box = document.getElementById(id);
  const max = Math.max(...data.map(d => d.value));
  data.forEach(d => {
    const width = (d.value / max) * 60; // percent of the row
    box.innerHTML +=
      `<div class="row">
         <div class="label">${d.name}</div>
         <div class="bar" style="width:${width}%"></div>
         <div class="value">${d.value.toLocaleString()}</div>
       </div>`;
  });
}

const total = monthly.reduce((sum, m) => sum + m.value, 0);
const best = monthly.reduce((a, b) => (b.value > a.value ? b : a));

document.getElementById("total").textContent = "£" + Math.round(total).toLocaleString();
document.getElementById("topCountry").textContent = countries[0].name;
document.getElementById("bestMonth").textContent = best.name;

drawChart("monthly", monthly);
drawChart("countries", countries);
